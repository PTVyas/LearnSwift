//
//  WebviewVC.swift
//  LearnSwift
//
//  Created by wos on 06/10/17.
//  Copyright © 2017 WOS. All rights reserved.
//

import UIKit

class WebviewVC: UIViewController, UIWebViewDelegate {

    @IBOutlet weak var webView: UIWebView!
    @IBOutlet weak var viewLoader: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let url = URL (string: "https://www.google.co.in/")
        let requestObj = URLRequest(url: url!)
        webView.delegate = self
        webView.loadRequest(requestObj)
        
        viewLoader.isHidden = true
        Function().setCornerRadius(objLayer: viewLoader.layer, radiusValue: 10)
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Web view Delegate method
    func webViewDidStartLoad(_ webView: UIWebView) {
        viewLoader.isHidden = false
    }
    
    func webViewDidFinishLoad(_ webView : UIWebView) {
        viewLoader.isHidden = true
    }
    // MARK: - Button Action Methods
    
    @IBAction func btnBackAction() {
        _ = navigationController?.popViewController(animated: true)
    }
}
