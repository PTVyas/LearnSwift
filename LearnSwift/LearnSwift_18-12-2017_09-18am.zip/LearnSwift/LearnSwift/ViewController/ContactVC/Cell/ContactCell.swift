//
//  ContactCell.swift
//  LearnSwift
//
//  Created by Piyush Vyas on 25/09/17.
//  Copyright © 2017 WOS. All rights reserved.
//

import UIKit

class ContactCell: UICollectionViewCell {
    @IBOutlet weak var viewCell: UIView!
    @IBOutlet weak var imgPhoto: UIImageView!
    @IBOutlet weak var lblPhoto: UILabel!
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
}
