//
//  ContactVC.swift
//  LearnSwift
//
//  Created by Piyush Vyas on 25/09/17.
//  Copyright © 2017 WOS. All rights reserved.
//

import UIKit
import Contacts

class ContactVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var collContact: UICollectionView!
        
    var  arrContact : NSMutableArray = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Function().showAlertMessage(Message: "Show contact date is static", AutoHide: false)
        getDeviceContact()
        self.collContact.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    // MARK: -
    
    func getDeviceContact() {
        let store = CNContactStore()
        store.requestAccess(for: .contacts, completionHandler: {
            granted, error in
            
            guard granted else {
                let alert = UIAlertController(title: "Can't access contact", message: "Please go to Settings -> MyApp to enable contact permission", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                return
            }
            
            let keysToFetch = [CNContactFormatter.descriptorForRequiredKeys(for: .fullName), CNContactPhoneNumbersKey] as [Any]
            let request = CNContactFetchRequest(keysToFetch: keysToFetch as! [CNKeyDescriptor])
            var cnContacts = [CNContact]()
            
            do {
                try store.enumerateContacts(with: request){
                    (contact, cursor) -> Void in
                    cnContacts.append(contact)
                }
            } catch let error {
                NSLog("Fetch contact error: \(error)")
            }
            
            NSLog(">>>> Contact list:")
            for contact in cnContacts {
                let fullName = CNContactFormatter.string(from: contact, style: .fullName) ?? "No Name"
                NSLog("Contact : \(fullName)")
                
                self.arrContact.add(fullName)
                //self.arrContact.add(contact)
            }
            self.collContact.reloadData()
        })
    }
    
    func retrieveContactsWithStore(store: CNContactStore) {
        /*
        do {
            let groups = try store.groups(matching: nil)
            let predicate = CNContact.predicateForContactsInGroup(withIdentifier: groups[0].identifier)
            //let predicate = CNContact.predicateForContactsMatchingName("John")
            let keysToFetch = [CNContactFormatter.descriptorForRequiredKeys(for: .fullName), CNContactEmailAddressesKey] as [Any]
            
            let contacts = try store.unifiedContacts(matching: predicate, keysToFetch: keysToFetch as! [CNKeyDescriptor])
            arrContact = (NSMutableArray)contacts
            dispatch_get_main_queue().asynchronously(execute: { () -> Void in
                self.collContact.reloadData()
            })
        } catch {
            print(error)
        }
        */
    }
    // MARK: - Button Action Methods
    @IBAction func btnBackAction() {
        _ = navigationController?.popViewController(animated: true)
    }
    
    // MARK: - Collection Delegate Methods
    /*
     func numberOfSections(in collectionView: UICollectionView) -> Int {
     return 10
     }
     */
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        //return 0
        return self.arrContact.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let width = 100;
        let height = 100;
        
       
        //width = (self.view.frame.size.width - 2) / 3 //some width
        //height = width //ratio
        
        let orientation = UIApplication.shared.statusBarOrientation
        if(orientation == .landscapeLeft || orientation == .landscapeRight) {
            //width = (self.view.frame.size.width - 5) / 6
            //height = width
        }
        else {
        }
        
        return CGSize(width: width, height: height);
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        //let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ContactCell
        
        var strTitle = "\(Function().randomString(length: 3)) \(Function().randomString(length: 5))"
        strTitle = (self.arrContact[indexPath.row] as! NSString) as String
        
            //let contactInfo = self.arrContact[indexPath.row] as
        //strTitle = CNContactFormatter.string(from: contactInfo, style: .fullName) ?? "No Name"
        
        //let contact = self.objects[indexPath.row]
        //let formatter = CNContactFormatter()
        //strTitle = formatter.stringFromContact(contact)
        
        //Function().setCornerRadius(objLayer: cell.viewCell.layer, radiusValue: 10)
        cell.viewCell.backgroundColor = UIColor.clear
        
        //cell.btnAdd.backgroundColor = UIColor.clear
        //Function().setCornerRadius(objLayer: cell.btnAdd.layer,radiusValue: cell.btnAdd.frame.width/2)
        
        
        cell.imgPhoto.image = nil;
        cell.imgPhoto.backgroundColor = Function().getRandomColor()
        /*
        if indexPath.row % 2 == 0 {
            cell.imgPhoto.image = UIImage.animatedImage(with: [#imageLiteral(resourceName: "swift")], duration: 0.80);
        }
        */
        
        cell.lblPhoto.isHidden = true
        if cell.imgPhoto.image == nil {
            cell.lblPhoto.text = Function().getFirstChar_OnString(strValue: strTitle).uppercased()
            cell.lblPhoto.numberOfLines = 1;
            cell.lblPhoto.isHidden = false
        }
        
        
        cell.lblTitle?.text = strTitle
        cell.lblTitle.numberOfLines = 0
        
        cell.backgroundColor = UIColor.white
        collectionView.backgroundColor = UIColor.white
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        /*
        let contact = arrContact[indexPath.row]
        let fName = CNContactFormatter.string(from: contact, style: .fullName) ?? "No Name"
        let lName = CNContactFormatter.string(from: contact, style: .fullName) ?? "No Name"
        let fullName = CNContactFormatter.string(from: contact, style: .fullName) ?? "No Name"
        let fullName = CNContactFormatter.string(from: contact, style: .fullName) ?? "No Name"
 
        let strMess = "You selected Contact: \nFname:\()"
         */
        Function().showAlertMessage(Message: "You selected cell \n'\(indexPath.item)'", AutoHide: false)
    }

}
