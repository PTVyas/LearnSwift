//
//  PickerVC.swift
//  LearnSwift
//
//  Created by Piyush Vyas on 26/09/17.
//  Copyright © 2017 WOS. All rights reserved.
//

import UIKit

class PickerVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    @IBOutlet weak var segment: UISegmentedControl!
    @IBOutlet weak var lblValue: UILabel!
    @IBOutlet weak var pvDatePicker: UIDatePicker!
    
    @IBOutlet weak var viewPicker: UIView!
    @IBOutlet weak var pickerList: UIPickerView!
    @IBOutlet weak var segment_componet: UISegmentedControl!
    
    var arrList : NSArray = []
    var segmentComponet : Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lblValue.text = " "
        lblValue.numberOfLines = 0
        pvDatePicker.addTarget(self, action: #selector(PickerVC.method as (PickerVC) -> () -> ()), for: .valueChanged)
        
        segment.selectedSegmentIndex = 0
        SegmentClick(segment)
        
        arrList = ["AAAA", "BBBB", "VVVV", "CCCC"]
        pickerList.dataSource = self
        pickerList.delegate = self
        
        segment_componet.selectedSegmentIndex = 0
        SegmentClick_componet(segment_componet)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    
    // MARK: -
    func method() {
        let todaysDate = pvDatePicker.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy hh:mm a"
        let dateString = dateFormatter.string(from: todaysDate)
        
        lblValue.text = "Curret Set Date:\n\n" + dateString
        lblValue.attributedText = Function().Set_SubStringColor(MainString: lblValue.text!,
                                                                MainString_Color: UIColor.lightGray,
                                                                SubString: dateString,
                                                                SubString_Color: lblValue.textColor)
    }
    
    // MARK: - Button Action Methods
    @IBAction func btnBackAction() {
        _ = navigationController?.popViewController(animated: true)
    }
    
    // MARK: - Segment
    @IBAction func SegmentClick(_ sender: UISegmentedControl) {
        lblValue.text = " "
        pvDatePicker.isHidden = true
        viewPicker.isHidden = true
        
        if sender.selectedSegmentIndex == 0 {
            viewPicker.isHidden = false
            pickerList.reloadAllComponents()
        }
        else if sender.selectedSegmentIndex == 1 {
            pvDatePicker.isHidden = false
            method()
        }
    }
    
    @IBAction func SegmentClick_componet(_ sender: UISegmentedControl)
    {
        segmentComponet = 0;
        if sender.selectedSegmentIndex == 0 {
            segmentComponet = 1;
        }
        else if sender.selectedSegmentIndex == 1 {
            segmentComponet = 2;
        }
        else if sender.selectedSegmentIndex == 2 {
            segmentComponet = 3;
        }
        else if sender.selectedSegmentIndex == 3 {
            segmentComponet = 4;
        }
        pickerList.reloadAllComponents()
    }
    
    // MARK: - Picker DelegateMethods
    // DataSource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        //return 1
        return segmentComponet
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //return arrList.count
        var values : Int = segmentComponet
        values = arrList.count
        return values
    }
    
    //func pickerview( _ : UIPickerView, titleForRow row: Int, forComponent component: Int) -> String! { return arrList[row] }
    // Delegate
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let values : NSString = arrList[row] as! NSString

        //Default Selected Segment Value
        self.pickerView(pickerView, didSelectRow: row, inComponent: component)
        
        /*
        if segmentComponet == 0 {
            return values as String
        }
        else if segmentComponet == 1 {
            return values as String
        }
        else if segmentComponet == 2 {
            return values as String
        }
        else if segmentComponet == 3 {
            return values as String
        }
        else if segmentComponet == 3 {
            return values as String
        }
        */
        return values as String
        
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        //print("Hai selezionato: \(arrList[row])")
        var values : String = " "
        //values = (arrList[row] as? String)!
        
        for i in 0 ..< segmentComponet {
            values = values + "\n"
            values = values + (arrList[pickerView.selectedRow(inComponent: i)] as! String)
        }
        lblValue.text = "Curret Set Value:\n" + values
        lblValue.attributedText = Function().Set_SubStringColor(MainString: lblValue.text!,
                                                                MainString_Color: UIColor.lightGray,
                                                                SubString: values,
                                                                SubString_Color: lblValue.textColor)
    }
    // MARK: -
}
