//
//  CameraGalleryVC.swift
//  LearnSwift
//
//  Created by wos on 10/11/17.
//  Copyright © 2017 WOS. All rights reserved.
//

import UIKit
import Foundation
import AVFoundation

class CameraGalleryVC: UIViewController, UIActionSheetDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var imgPhoto: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        imgPhoto.image = UIImage.init(named: "")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    // MARK: -
    func openCamera() {
        if AVCaptureDevice.authorizationStatus(forMediaType: AVMediaTypeVideo) ==  AVAuthorizationStatus.authorized {
            NSLog("Already Authorized")
        } else {
            AVCaptureDevice.requestAccess(forMediaType: AVMediaTypeVideo, completionHandler: { (granted: Bool) -> Void in
                if granted == true {
                    NSLog("User Granted")
                } else {
                    NSLog("User Rejected")
                }
            })
        }
        
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera;
            imagePicker.allowsEditing = false
            self.present(imagePicker, animated: true, completion: nil)
        }
        else {
            Function().showAlertMessage(Message: "Unable to find Camera in device", AutoHide: false)
        }
    }
    
    func openPhotoLibrary() {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
        else {
            Function().showAlertMessage(Message: "Unable to Photo Library in device", AutoHide: false)
        }
    }
    
    // MARK: - Button Action Methods
    @IBAction func btnBackAction() {
        _ = navigationController?.popViewController(animated: true)
    }
    
    @IBAction func uploadPhotoAction() {
        let actinSheet  = UIAlertController(title: "Upload Photo", message:  "Choose the options and upload the photo", preferredStyle: .actionSheet)
        
        // Create and add the Cancel action
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { action -> Void in
            // Just dismiss the action sheet
        }
        actinSheet.addAction(cancelAction)
        
        let takePicture_camerAction = UIAlertAction(title: "Camera", style: .default) { action -> Void in
            self.openCamera()
        }
        actinSheet.addAction(takePicture_camerAction)
        
        let takePicture_photoAction = UIAlertAction(title: "Photo Library", style: .default) { action -> Void in
            self.openPhotoLibrary()
        }
        actinSheet.addAction(takePicture_photoAction)
        
        // Present the AlertController
        self.present(actinSheet, animated: true, completion: nil)
    }
    
    // MARK: - UIImagePickerControllerDelegate Mthod
    func imagePickerController( _ picker: UIImagePickerController,didFinishPickingMediaWithInfo info: [String : AnyObject]) {
    //private func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        var image = info[UIImagePickerControllerOriginalImage] as! UIImage
        image = info[UIImagePickerControllerEditedImage] as! UIImage
        imgPhoto.image = image
        
        dismiss(animated:true, completion: nil)
    }
}
