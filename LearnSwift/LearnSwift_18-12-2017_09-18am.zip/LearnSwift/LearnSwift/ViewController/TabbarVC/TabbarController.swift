//
//  TabbarController.swift
//  LearnSwift
//
//  Created by Piyush Vyas on 25/09/17.
//  Copyright © 2017 WOS. All rights reserved.
//

import UIKit

class TabbarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        UITabBar.appearance().tintColor = UIColor(red: 224.0/255.0, green: 46.0/255.0, blue: 34.0/255.0, alpha: 1.0)
        
        if let tabBarItems = tabBar.items {
            for item in tabBarItems {
                item.imageInsets = UIEdgeInsetsMake(6,0,-6,0)
                item.title = nil
            }
        }
        
        /*
        let tabOne = self.storyboard?.instantiateViewController(withIdentifier: "Tab1VC") as! Tab1VC
        let tabOneBarItem = UITabBarItem(title: "1", image: UIImage(named: "tab1"), selectedImage: UIImage(named: "ac_tab1"))
        tabOne.tabBarItem = tabOneBarItem
         
        let tabTwo = self.storyboard?.instantiateViewController(withIdentifier: "Tab2VC") as! Tab2VC
        let tabTwoBarItem = UITabBarItem(title: "2", image: UIImage(named: "tab2"), selectedImage: UIImage(named: "ac_tab2"))
        tabTwo.tabBarItem = tabTwoBarItem
        
        let tabThree = self.storyboard?.instantiateViewController(withIdentifier: "Tab3VC") as! Tab3VC
        let tabThreeBarItem = UITabBarItem(title: "3", image: UIImage(named: "tab3"), selectedImage: UIImage(named: "ac_tab3"))
        tabThree.tabBarItem = tabThreeBarItem
        
        //let viewControllerList = [tabOne, tabTwo, tabThree]
        //self.tabBarItem = viewControllerList
        */
        
        /*
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swiped))
        swipeRight.direction = UISwipeGestureRecognizerDirection.right
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(swiped))
        swipeLeft.direction = UISwipeGestureRecognizerDirection.left
        self.view.addGestureRecognizer(swipeLeft)
        */
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: -
    func swiped(_ gesture: UISwipeGestureRecognizer) {
        if gesture.direction == .left {
            if (self.tabBarController?.selectedIndex)! < (tabBar.items?.count)! { // set your total tabs here
                self.tabBarController?.selectedIndex += 1
            }
        } else if gesture.direction == .right {
            if (self.tabBarController?.selectedIndex)! > 0 {
                self.tabBarController?.selectedIndex -= 1
            }
        }
    }
    

}
