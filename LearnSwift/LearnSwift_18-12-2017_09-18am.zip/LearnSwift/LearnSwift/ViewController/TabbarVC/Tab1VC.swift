//
//  Tab1VC.swift
//  LearnSwift
//
//  Created by Piyush Vyas on 25/09/17.
//  Copyright © 2017 WOS. All rights reserved.
//

import UIKit

class Tab1VC: UIViewController {

    @IBOutlet weak var viewTitle: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: -
    
    // MARK: - Button Action Methods
    @IBAction func btnBackAction() {
        
        _ = navigationController?.popViewController(animated: true)
    }
    

}
