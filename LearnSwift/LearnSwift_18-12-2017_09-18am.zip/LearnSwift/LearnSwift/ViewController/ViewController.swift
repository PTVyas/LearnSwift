
//
//  ViewController.swift
//  LearnSwift
//
//  Created by WOS_iMac_2 on 8/23/17.
//  Copyright © 2017 WOS. All rights reserved.
//

import UIKit

let _kHelloWorld                    = "Hello World"
let _kAlert                         = "Alert"
let _kAlertAutoHide                 = "Alert (Auto Hide)"
let _kString                        = "String"
let _kTableView                     = "TableView"
let _kCollectionView                = "Collectionview"
let _kTabbar                        = "Tabbar"
let _kContact                       = "Contact"
let _kPicker                        = "Picker Controller \n(Date Picker & Picker View)"
let _kMap                           = "Map"
let _kWebView                       = "Webview"
let _kSideMenu                      = "Sidemenu"
let _kAnimation                     = "Animation"
let _kCameraGallery                 = "Camera & Gallery"

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    //MARK:- Outlet
    @IBOutlet weak var viewTitle: UIView!
    @IBOutlet weak var tblList: UITableView!
    
    var arrList:NSMutableArray = []
    
    //MARK:-
    override func viewDidLoad() {
        super.viewDidLoad()
        
        arrList.add(_kCameraGallery)
        //arrList.add(_kAnimation) //--> Pending
        //arrList.add(_kSideMenu) //--> Pending
        arrList.add(_kWebView)
        arrList.add(_kMap)
        arrList.add(_kPicker)
        arrList.add(_kContact) //--> Pending
        arrList.add(_kTabbar)
        arrList.add(_kCollectionView)
        arrList.add(_kTableView)
        //arrList.add(_kString) //-> Done It's working | check function : self.stringFunctionOpetation()
        arrList.add(_kAlertAutoHide)
        arrList.add(_kAlert)
        arrList.add(_kHelloWorld)
        
        tblList.dataSource = self
        tblList.delegate = self
        tblList.tableFooterView = UIView.init(frame: .zero)
        tblList.separatorInset = .zero
        tblList.layoutMargins = .zero
        tblList.separatorColor = UIColor.clear
    
        //------------>
        //String Related Opration in this Function
        //self.stringFunctionOpetation()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    func stringFunctionOpetation()
    {
        //String Related Function
        var value : String
        value = "\n\n\nHello\n\nHi\n\n....\n\n"
        print(value);
        print("-------------------------------");
        print("Trimming String:\n",Function().trimmingString(strValue: value as String))
        print("Check string is Empty? - ",Function().string_Empty(strValue: value as String))
        print("Replace string (new line == _) - ",Function().replaceValueInString(mainString: value, replaceValue: "\n", toValue: "_"))
        value = " "
        print("Check string is Empty? - ",Function().string_Empty(strValue: value as String))
        print("PlaceHolder string - ",Function().placeHolderValue(value, "##"))
        value = "123456"
    }
    
    //MARK:- Table Delegate Methods
    func tableView(_ tableView:UITableView, numberOfRowsInSection section:Int) -> Int
    {
        return arrList.count
    }
    
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell:UITableViewCell=UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "mycell")
        
        var value = ""
        value = arrList[indexPath.row] as! String
        value = value.localizedCapitalized
        
        cell.textLabel?.text =  value //(arrList[indexPath.row] as! NSString) as String
        cell.textLabel?.numberOfLines = 0;
        
        //cell.detailTextLabel?.text="subtitle#\(indexPath.row)"
        
        //tableView.separatorColor = UIColor.darkGray
        tableView.separatorColor = viewTitle.backgroundColor
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true);
        
        let value = (arrList[indexPath.row] as! NSString) as String
        if value.uppercased() == _kHelloWorld.uppercased() {
            Function().showAlertMessage(Message: _kHelloWorld.uppercased(), AutoHide: false)
        }
        else if value.uppercased() == _kAlert.uppercased() {
            Function().showAlertMessage(Message: "Alert Message".uppercased(), AutoHide: false)
        }
        else if value.uppercased() == _kAlertAutoHide.uppercased() {
            Function().showAlertMessage(Message: "Alert Message\n(Auto Hide)".uppercased(), AutoHide: true)
        }
        else if value.uppercased() == _kString.uppercased() {
            //Code----->
            Function().showAlertMessage(Message: "Work in Porgress...", AutoHide: false)
        }
        else if value.uppercased() == _kTableView.uppercased() {
            let objVC = self.storyboard?.instantiateViewController(withIdentifier: "TableVC") as! TableVC
            self.navigationController?.pushViewController(objVC, animated: true)
        }
        else if value.uppercased() == _kCollectionView.uppercased() {
            let objVC = self.storyboard?.instantiateViewController(withIdentifier: "CollectionVC") as! CollectionVC
            self.navigationController?.pushViewController(objVC, animated: true)
        }
        else if value.uppercased() == _kTabbar.uppercased() {
            let objVC = self.storyboard?.instantiateViewController(withIdentifier: "TabbarController") as! TabbarController
            self.navigationController?.pushViewController(objVC, animated: true)
        }
        else if value.uppercased() == _kContact.uppercased() {
            let objVC = self.storyboard?.instantiateViewController(withIdentifier: "ContactVC") as! ContactVC
            self.navigationController?.pushViewController(objVC, animated: true)
        }
        else if value.uppercased() == _kPicker.uppercased() {
            let objVC = self.storyboard?.instantiateViewController(withIdentifier: "PickerVC") as! PickerVC
            self.navigationController?.pushViewController(objVC, animated: true)
        }
        else if value.uppercased() == _kMap.uppercased() {
            let objVC = self.storyboard?.instantiateViewController(withIdentifier: "MapVC") as! MapVC
            self.navigationController?.pushViewController(objVC, animated: true)
        }
        else if value.uppercased() == _kWebView.uppercased() {
            let objVC = self.storyboard?.instantiateViewController(withIdentifier: "WebviewVC") as! WebviewVC
            self.navigationController?.pushViewController(objVC, animated: true)
        }
        else if value.uppercased() == _kSideMenu.uppercased() {
            let objVC = self.storyboard?.instantiateViewController(withIdentifier: "SidemenuVC") as! SidemenuVC
            self.navigationController?.pushViewController(objVC, animated: true)
        }
        else if value.uppercased() == _kAnimation.uppercased() {
            Function().showAlertMessage(Message: "Work in Porgress...", AutoHide: true)
            
            //let objVC = self.storyboard?.instantiateViewController(withIdentifier: "SidemenuVC") as! SidemenuVC
            //self.navigationController?.pushViewController(objVC, animated: true)
        }
        else if value.uppercased() == _kCameraGallery.uppercased() {
            let objVC = self.storyboard?.instantiateViewController(withIdentifier: "CameraGalleryVC") as! CameraGalleryVC
            self.navigationController?.pushViewController(objVC, animated: true)
        }
        else
        {
            Function().showAlertMessage(Message: "Work in Porgress...", AutoHide: true)
        }
    }
}
