//
//  MapVC.swift
//  LearnSwift
//
//  Created by Piyush Vyas on 27/09/17.
//  Copyright © 2017 WOS. All rights reserved.
//

import UIKit
import MapKit

class MapVC: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate
{
    @IBOutlet weak var mapLocation: MKMapView!
    @IBOutlet weak var btnCurretLocation: UIButton!
    
    @IBOutlet weak var viewInfo: UIView!
    @IBOutlet weak var lblLocation: UILabel!
    
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        Function().setCornerRadius(objLayer: btnCurretLocation.layer, radiusValue: btnCurretLocation.frame.height/2)
        Function().setBorderWidth(objLayer: btnCurretLocation.layer, widthValue: 0.75, borderColor: UIColor.black)
        
        
        Function().setCornerRadius(objLayer: viewInfo.layer, radiusValue: 10)
        lblLocation.text = "Loading..."
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestAlwaysAuthorization()
            locationManager.startUpdatingLocation()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    // MARK: -
    func map_InfoShow( coordinate: CLLocationCoordinate2D)
    {
        lblLocation.text = "Loading..."
        
        // Add below code to get address for touch coordinates.
        let geoCoder = CLGeocoder()
        let location = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
        geoCoder.reverseGeocodeLocation(location, completionHandler: { (placemarks, error) -> Void in
            
            // Place details
            var placeMark: CLPlacemark!
            placeMark = placemarks?[0]
            
            // Address dictionary
            print(placeMark.addressDictionary as Any)
            
            // Location name
            let locationName : NSString = "Name: \(placeMark.addressDictionary!["Name"])" as NSString
            
            // Street address
            let street : NSString = "\nStreet: \(placeMark.addressDictionary!["Thoroughfare"])" as NSString
            
            // City
            let city : NSString = "\nCity: \(placeMark.addressDictionary!["City"])" as NSString
            
            // Zip code
            let zip : NSString = "\nZip: \(placeMark.addressDictionary!["ZIP"])" as NSString
            
            // Country
            let country : NSString = "\nCountry: \(placeMark.addressDictionary!["Country"])" as NSString
          
            //Latitude-Longitude
            let latLog = "\nLat-Log: " + "\(coordinate.latitude), \(coordinate.longitude)"
            
            let value = (locationName as String) + (street as String) + (city  as String) + (zip as String) + (country as String) + (latLog as String)
            self.lblLocation.text = value as String
        })
    }
    
    func map_Zoom( coordinate: CLLocationCoordinate2D, mapview: MKMapView)
    {
        let center = CLLocationCoordinate2D(latitude: coordinate.latitude, longitude: coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        mapview.setRegion(region, animated: true)
    }
    
    
    // MARK: - Curret Location Delegate Methods
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        self.locationManager.stopUpdatingLocation()
    }
    
    func locationUpdateNotification(notification: NSNotification) {
        if let userInfo = notification.userInfo?["location"] as? CLLocation {
            //Store user location
            lblLocation.text = "\(userInfo.coordinate.latitude), \(userInfo.coordinate.longitude)"
        }
    }
    
    // MARK: - Button Action Methods
    @IBAction func btnBackAction() {
        _ = navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnCurretLocationAction() {
        
        if (locationManager.location?.coordinate.latitude == nil)  {
            Function().showAlertMessage(Message: "Unable to get your curret location", AutoHide: true)
            return
        }
        //Set Zoom the Map
        map_Zoom(coordinate: (locationManager.location?.coordinate)!, mapview: mapLocation)
        
        //Get Lat-Log
        map_InfoShow(coordinate: (locationManager.location?.coordinate)!)
    }
    
    // MARK: - Mapview Delegate Method
    func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
        
        map_InfoShow(coordinate: mapView.centerCoordinate)
    }
}
