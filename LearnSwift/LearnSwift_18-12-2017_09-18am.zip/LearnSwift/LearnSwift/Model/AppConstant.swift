//
//  AppConstant.swift
//  MyNotes
//
//  Created by Bhargav on 09/09/17.
//  Copyright © 2017 wos. All rights reserved.
//

import Foundation

struct AppConstant {
    //Color
    //static let COLOR_Titlebar = UIColor(red: 224.0/255.0, green: 46.0/255.0, blue: 34.0/255.0, alpha: 1.0)
    
    static let AdsMob_Key                               = "ca-app-pub-7566313460376440~7623601015"
    
    //Nanner Ads Id
    static let AdsMob_Key_Banner                        = "ca-app-pub-7566313460376440/4251332217"

    //Interstitial (Full Screen) AdsId
    //static let AdsMob_Key_Interstitial                  = "ca-app-pub-3940256099942544/4411468910"
    static let AdsMob_Key_Interstitial                  = "ca-app-pub-3940256099942544/4411468910" //Testing
    
    //Video Ads Id
    //static let AdsMob_Key_Video                         = "2077ef9a63d2b398840261c8221a0c9a"
    static let AdsMob_Key_Video                         = "ca-app-pub-3940256099942544/1712485313" //Testing
}
